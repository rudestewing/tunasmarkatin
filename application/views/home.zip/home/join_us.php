<!-- join us -->
<section class="pb_sm_py_cover text-center cover-bg-black cover-bg-opacity-4" style="background-image: ">
      <div class="container">

        <div class="row align-items-center">
          <div class="col-md-12">
            <h2 class="heading mb-3">Join us</h2>
            <p class="sub-heading mb-5 pb_color-light-opacity-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora fuga nihil odit ut sunt. Nam id, consequatur beatae recusandae, dolores molestiae in perferendis architecto ratione enim, debitis praesentium mollitia iure.</p>
            <p><a href="#section-contact" role="button" class="btn smoothscroll pb_outline-light p-3 rounded-0 pb_font-13 pb_letter-spacing-2">Daftar</a></p>
          </div>  
        </div>

      </div>
    </section>
    <!-- end join us -->