<?php 

require_once('head.php');
require_once('navigasi.php');
require_once('header.php');
require_once('about_our_school.php');
require_once('ekskul.php');
require_once('join_us.php');
require_once('kegiatan_sekolah.php');
require_once('guru.php');
require_once('alumni.php');
require_once('contac_us.php');
require_once('footer.php');