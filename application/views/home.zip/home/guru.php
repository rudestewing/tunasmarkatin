<!-- daftar guru -->
 <section class="pb_section bg-light bg-image with-overlay" data-section="attorneys" id="section-attorneys" style="background-image:">
      <div class="container">
        <div class="row justify-content-md-center text-center mb-5">
          <div class="col-lg-7">
            <h2 class="mt-0 heading-border-top light font-weight-normal text-white">Guru &amp; Staff</h2>
            <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus quaerat, dolorum beatae modi dolor ad similique eligendi nihil earum sit, nam facere nulla quae debitis, harum voluptatibus consequatur assumenda molestiae?</p>
          </div>
        </div>
        <div class="row">
          <div class="col-md">
            <div class="card text-center pb_card_v1 mb-4">
              <img class="card-img-top rounded-circle w-50 mx-auto" src="" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title mt-0 mb-2">Guru A</h4>
                <h6 class="card-subtitle mb-2">Kepsek</h6>
                <p><a href="#">Read Full Bio</a></p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="card text-center pb_card_v1 mb-4">
              <img class="card-img-top rounded-circle w-50 mx-auto" src="" alt="guru & staff">
              <div class="card-body">
                <h4 class="card-title mt-0 mb-2">Guru A</h4>
                <h6 class="card-subtitle mb-2">Kepsek</h6>
                <p><a href="#">Read Full Bio</a></p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="card text-center pb_card_v1 mb-4">
              <img class="card-img-top rounded-circle w-50 mx-auto" src="" alt="guru & staff">
              <div class="card-body">
                <h4 class="card-title mt-0 mb-2">Guru A</h4>
                <h6 class="card-subtitle mb-2">Kepsek</h6>
                <p><a href="#">Read Full Bio</a></p>
              </div>
            </div>
          </div>
       
        </div>
      </div>
    </section>
<!-- end daftar guru -->