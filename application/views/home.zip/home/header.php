<!-- header -->

  <section class="pb_cover_v1 text-left cover-bg-black cover-bg-opacity-4" style="background-image: url()" id="section-home">
      <div class="container">
        <div class="row align-items-center justify-content-end">
          <div class="col-md-6  order-md-1">

            <h2 class="heading mb-3">SMA Tunas Markatin</h2>
            <div class="sub-heading"><p class="mb-5">Right Choice  For You ! </p>
            <p><a href="#section-contact" role="button" class="btn smoothscroll pb_outline-light btn-xl pb_font-13 p-4 rounded-0 pb_letter-spacing-2">Come Join Us</a></p>
            </div>
            
          </div>  
        </div>
      </div>
    </section>
<!-- end header -->