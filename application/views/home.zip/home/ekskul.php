<!-- ekskul -->
 <section class="pb_section" data-section="why-us" id="section-why-us">
      <div class="container">
        <div class="row justify-content-md-center text-center mb-5">
          <div class="col-lg-7">
            <h2 class="mt-0 heading-border-top font-weight-normal">Ekstra Kulikuler</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi ratione, dolores molestias nulla unde placeat facere laboriosam saepe laborum ipsum, quod, fugiat molestiae animi, quos nostrum provident? Ratione, enim, non.</p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-7">
            <div class="images right">
              <img class="img1 img-fluid" src="" alt="ekskul">
              <img class="img2" src="" alt="ekskul">
            </div>
          </div>
          <div class="col-lg-5 pl-md-5 pl-sm-0">
            <div id="exampleAccordion" class="pb_accordion" data-children=".item">
              <div class="item">
                <a data-toggle="collapse" data-parent="#exampleAccordion" href="#exampleAccordion1" aria-expanded="true" aria-controls="exampleAccordion1" class="pb_font-18">Futsal</a>
                <div id="exampleAccordion1" class="collapse show" role="tabpanel">
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi accusantium, at aliquid! Laborum quibusdam culpa doloremque sed illum, laboriosam, quo ad iure, accusamus, totam nulla rem! Nostrum ad, harum labore.</p>
                </div>
              </div>
              <div class="item">
                <a data-toggle="collapse" data-parent="#exampleAccordion" href="#exampleAccordion2" aria-expanded="false" aria-controls="exampleAccordion2" class="pb_font-18">Basket</a>
                <div id="exampleAccordion2" class="collapse" role="tabpanel">
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi accusantium, at aliquid! Laborum quibusdam culpa doloremque sed illum, laboriosam, quo ad iure, accusamus, totam nulla rem! Nostrum ad, harum labore.</p>
                </div>
              </div>
              <div class="item">
                <a data-toggle="collapse" data-parent="#exampleAccordion" href="#exampleAccordion3" aria-expanded="false" aria-controls="exampleAccordion3" class="pb_font-18">Kesenian</a>
                <div id="exampleAccordion3" class="collapse" role="tabpanel">
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi accusantium, at aliquid! Laborum quibusdam culpa doloremque sed illum, laboriosam, quo ad iure, accusamus, totam nulla rem! Nostrum ad, harum labore.</p>
                </div>
              </div>
              <div class="item">
                <a data-toggle="collapse" data-parent="#exampleAccordion" href="#exampleAccordion4" aria-expanded="false" aria-controls="exampleAccordion4" class="pb_font-18">Programing</a>
                <div id="exampleAccordion4" class="collapse" role="tabpanel">
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi accusantium, at aliquid! Laborum quibusdam culpa doloremque sed illum, laboriosam, quo ad iure, accusamus, totam nulla rem! Nostrum ad, harum labore.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

     <section class="pb_section">
      <div class="multiple-items pb_slide_v1">
        <div>
          <a href="#" class="link-block">
            <img src="" alt="" class="img-fluid">
            <div class="slide-text">
              <h2>Kegiatan sekolah </h2>
            </div>
          </a>
        </div>
        <div>
          <a href="#" class="link-block">
            <img src="" alt="" class="img-fluid">
            <div class="slide-text">
              <h2>Kegiatan sekolah</h2>
            </div>
          </a>
        </div>
        <div>
          <a href="#" class="link-block">
            <img src="" alt="" class="img-fluid">
            <div class="slide-text">
              <h2>Kgiatan Sekolah</h2>
            </div>
          </a>
        </div>
        <div>
          <a href="#" class="link-block">
            <img src="" alt="" class="img-fluid">
            <div class="slide-text">
              <h2>Kegiatan sekolah</h2>
            </div>
          </a>
        </div>
      </div>

    </section>
    <!-- end ekskul -->