<!-- about our school -->
 <section class="pb_section pb_section_v1" data-section="about" id="section-about">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 pr-md-5 pr-sm-0">
            <h2 class="mt-0 heading-border-top mb-3 font-weight-normal">Who We Are</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam voluptatem libero error qui ut veritatis, iure mollitia, maiores sit animi sapiente ipsam rerum labore omnis laborum magni odio aliquam ea.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia eveniet qui eos, pariatur accusamus labore possimus animi atque doloremque voluptate maxime ex cumque recusandae nostrum rem, eligendi nulla, iusto temporibus!</p>
          </div>
          <div class="col-lg-7">
            <div class="images">
              <img class="img1 img-fluid" src="" alt="">
              <img class="img2" src="" alt="free Template">
            </div>
          </div>
          
        </div>
      </div>  
    </section>

      <section class="pb_section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md">
            <div class="media pb_media_v2 d-block text-center mb-3">
              <div class="media-body">
                <h3 class="mt-0 pb_font-20">Moto Sekolah</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam deleniti non magni excepturi dolorum veniam, ea vel quod at qui voluptatibus, debitis, esse eum iusto! Soluta omnis obcaecati, dignissimos itaque.</p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="media pb_media_v2 d-block text-center  mb-3">
              <div class="media-body">
                <h3 class="mt-0 pb_font-20">Visi</h3>
               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non dolor perspiciatis, repellendus optio amet ex laborum vitae sapiente numquam suscipit hic iste in, minima quis dolorem voluptates et voluptatum nulla!</p>
              </div>
            </div>
          </div>
          <div class="col-md">
            <div class="media pb_media_v2 d-block text-center  mb-3">
              <div class="media-body">
                <h3 class="mt-0 pb_font-20">Misi</h3>
               <ul>
                 <li>satu</li>
                 <li>dua</li>
                 <li>tiga</li>
                 <li>empat</li>
               </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<!-- end about our school -->