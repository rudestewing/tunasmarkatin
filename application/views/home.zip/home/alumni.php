 <!-- alumni -->
 <section class="pb_section pb_testimonial_v1" data-section="testimonials" id="section-testimonials">
      <div class="container">
        <div class="row justify-content-md-center text-center mb-5">
          <div class="col-lg-7">
            <h2 class="mt-0 heading-border-top font-weight-normal">Tangapan Alumni</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio, aliquid soluta consectetur unde molestias nulla vel incidunt culpa dolorum eligendi neque possimus voluptate cupiditate nostrum consequuntur ipsa. Laudantium, labore, aperiam.</p>
          </div>
        </div>
        <div class="row justify-content-md-center">
          <div class="col-md-10 col-sm-12 mb-5">
            <div class="single-item-no-arrow pb_slide_v1">
              <div>
                <div class="media">
                  <img class="d-flex img-fluid rounded-circle mb-sm-5" src="" alt="alumni">
                  <div class="media-body pl-md-5 pl-sm-0">
                    <blockquote>
                      <p>&ldquo;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate ea, quibusdam consequatur ducimus autem eligendi nulla, aliquid iusto necessitatibus dicta, quae a aspernatur saepe, tempore. Rerum possimus molestias officia numquam..&rdquo;</p>
                      <p class="pb_author"><cite class="text-uppercase">Nama</cite> Pekerjaan</p>
                    </blockquote>
                  </div>
                </div>
              </div>
              <div>
                <div class="media">
                  <img class="d-flex img-fluid rounded-circle mb-sm-5" src="" alt="alumni">
                  <div class="media-body pl-md-5 pl-sm-0">
                    <blockquote>
                      <p>&ldquo;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate ea, quibusdam consequatur ducimus autem eligendi nulla, aliquid iusto necessitatibus dicta, quae a aspernatur saepe, tempore. Rerum possimus molestias officia numquam..&rdquo;</p>
                      <p class="pb_author"><cite class="text-uppercase">Nama</cite> Pekerjaan</p>
                    </blockquote>
                  </div>
                </div>
              </div>
              <div>
                <div class="media">
                  <img class="d-flex img-fluid rounded-circle mb-sm-5" src="" alt="alumni">
                  <div class="media-body pl-md-5 pl-sm-0">
                    <blockquote>
                      <p>&ldquo;Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate ea, quibusdam consequatur ducimus autem eligendi nulla, aliquid iusto necessitatibus dicta, quae a aspernatur saepe, tempore. Rerum possimus molestias officia numquam..&rdquo;</p>
                      <p class="pb_author"><cite class="text-uppercase">Nama</cite> Pekerjaan</p>
                    </blockquote>
                  </div>
                </div>
              </div>
              
            </div>

          </div>

        </div>
      </div>
    </section>
    <!-- alumni -->