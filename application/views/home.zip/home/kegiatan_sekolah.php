 <!-- acara sekolah -->

      <section class="pb_section pb_bg-half" data-section="practicing-areas" id="section-practicing-areas">
      <div class="container">
        <div class="row justify-content-md-center text-center mb-5">
          <div class="col-lg-7">
            <h2 class="mt-0 heading-border-top font-weight-normal">Acara Sekolah</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora, ipsa voluptates laboriosam cupiditate possimus debitis, totam impedit asperiores quisquam in voluptatibus molestiae, aspernatur id optio nobis enim. Illo, eius, sint.</p>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">

            <div class="single-item pb_slide_v2">
              <div>
                <div class="d-lg-flex d-md-block slide_content">
                  <div class="pb_content-media" style="background-image: url();"></div>
                  <div class="slide_content-text text-center">
                    <div class="pb_icon_v1"><i class=""></i></div>
                    <h3 class="font-weight-normal mt-0 mb-4">Acara A</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                  </div>
                </div>
              </div>
              <div class="d-lg-flex d-md-block slide_content">
                  <div class="pb_content-media" style="background-image: url();"></div>
                  <div class="slide_content-text text-center">
                    <div class="pb_icon_v1"><i class=""></i></div>
                    <h3 class="font-weight-normal mt-0 mb-4">Acara A</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                  </div>
                </div>
                <div class="d-lg-flex d-md-block slide_content">
                  <div class="pb_content-media" style="background-image: url();"></div>
                  <div class="slide_content-text text-center">
                    <div class="pb_icon_v1"><i class=""></i></div>
                    <h3 class="font-weight-normal mt-0 mb-4">Acara A</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt excepturi doloremque impedit perspiciatis recusandae. Asperiores veniam similique quod voluptas nihil! Dolorum, necessitatibus perferendis debitis pariatur voluptatum similique quae commodi. Nam.</p>
                  </div>
                </div>

             

            </div>

          </div>
        </div>
      </div>  
    </section>
    <!-- end acara sekolah -->